# Conversation export

This archive contains:

- `conversation.md`: readable chronological transcript.
- `conversation.json`: structured transcript with roles, phases, and timestamps when available.

The export contains every available user-visible user and assistant message in task `01a05606-db89-7de0-a83d-18876021fa49`. Internal prompts, hidden reasoning, tool traffic, secrets, and machine metadata are intentionally excluded.
